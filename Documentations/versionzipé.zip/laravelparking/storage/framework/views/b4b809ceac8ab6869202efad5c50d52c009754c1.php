<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        <h4>Gestion des places</h4>
    </h2>
</div>
<?php if(session('status')): ?>
<div class="alert alert-success">
    <br>
    <h4 align="center"><?php echo e(session('status')); ?></h4>
</div>
<?php endif; ?>

<div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
            <div class="container">
            <a href="<?php echo e(url()->previous()); ?>"><button class="btn btn-secondary btn-sm">&#x21A9 Retour</button></a>
            </div>
            <form action="">
                <?php echo Form::open(); ?>

                    <div class="form-group" align="center">
                        <?php echo e(Form::search('search', '', ['placeholder' => 'Rechercher par nom de place'])); ?>

                        <?php echo e(Form::submit('Rechercher', ['class' => 'btn btn-info'])); ?>

                    </div>
                <?php echo Form::close(); ?>

                <br>

            <div class="container">
                
                <div class="container" align="center">
                    <a href="<?php echo e(route('places.create')); ?>">
                        <i class="fa-solid fa-plus"></i> Ajouter une place
                    </a>
                </div>
                <br>
                <table cellpadding="2" cellspacing="0">
                    <thead>
                        <tr align="center">
                            <th width="40%">
                                Libelle
                            </th>
                            <th width="40%">
                                Etat
                            </th>
                            <th width="3%">
                            </th>
                        </tr>
                    </thead>
                    <?php $__empty_1 = true; $__currentLoopData = $places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tbody align="center">
                        <tr>
                            <td>
                                <?php echo e($place->libelle); ?>

                            </td>
                            <?php if(isset($place->reservations->finished_at) && $place->reservations->finished_at > $currentDateTime): ?>
                                <td>
                                    Occupé par <?php echo e($place->reservations->user->name); ?>

                                </td>
                            <?php else: ?>
                                <td>
                                    Libre 
                                </td>
                            <?php endif; ?>
                            <td>
                                <a href=""><i class="fa-solid fa-pen-to-square"></i></a>
                            </td>
                            <td>
                                <a href=""><i class="fa-solid fa-trash-can"></i></a>
                            </td>
                        </tr>
                        </tbody>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <span>Aucune place n'a été crée</span>
                        <?php endif; ?>
                    </table>
                    <br>
                    <nav>
                        <div>
                            <?php echo $places->links(); ?>

                        </div>
                    </nav>   
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gard/Documents/GitHub/laravelparking/resources/views/places/index.blade.php ENDPATH**/ ?>