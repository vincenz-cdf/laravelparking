<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        <h4>Gestion des salariés</h4>
    </h2>
</div>
<?php if(session('status')): ?>
<div class="alert alert-success">
    <br>
    <h4 align="center"><?php echo e(session('status')); ?></h4>
</div>
<?php endif; ?>

<div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
            <div class="container">
            <a href="<?php echo e(url()->previous()); ?>"><button class="btn btn-secondary btn-sm">&#x21A9 Retour</button></a>
            </div>
            <form action="">
                <?php echo Form::open(); ?>

                    <div class="form-group" align="center">
                        <?php echo e(Form::search('search', '', ['placeholder' => 'Rechercher par nom ou email'])); ?>

                        <?php echo e(Form::submit('Rechercher', ['class' => 'btn btn-info'])); ?>

                    </div>
                <?php echo Form::close(); ?>

                <br>

            <div class="container">
                
                <div class="container" align="center">
                    <a href="<?php echo e(route('users.create')); ?>">
                        <i class="fa-solid fa-plus"></i> Ajouter un salarié
                    </a>
                </div>
                <br>
                <table cellpadding="2" cellspacing="0">
                    <thead>
                        <tr align="center">
                            <th width="30%">
                                Nom
                            </th>
                            <th width="30%">
                                Prenom
                            </th>
                            <th width="30%">
                                Mail
                            </th>
                            <th width="3%">
                            </th>
                        </tr>
                    </thead>
                    <?php $__empty_1 = true; $__currentLoopData = $salaries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salarie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tbody align="center">
                        <tr>
                            <td>
                                <?php echo e($salarie->name); ?>

                            </td>
                            <td>
                                <?php echo e($salarie->prenom); ?>

                            </td>
                            <td>                                                
                                <?php echo e($salarie->email); ?>&#x2800
                            </td>
                            <td>
                                <a href="<?php echo e(route('users.edit', $salarie->id)); ?>"><i class="fa-solid fa-pen-to-square"></i></a>                                            
                            </td>
                            <td>
                                <a href="<?php echo e(route('users.remove', $salarie->id)); ?>"><i class="fa-solid fa-trash-can"></i></a>
                            </td>
                            <?php if($salarie->active == 0): ?>
                            <td>
                                <a href="<?php echo e(route('users.activate', $salarie->id)); ?>"><i class="fa-solid fa-user-xmark"></i></a>
                            </td>
                            <?php else: ?>
                            <td>
                                <i class="fa-solid fa-user-check"></i>
                            </td>
                            <?php endif; ?>
                        </tr>
                        </tbody>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <span>Aucun compte n'a été crée</span>
                        <?php endif; ?>
                    </table>
                    <br>
                    <nav>
                        <div>
                            <?php echo $salaries->links(); ?>

                        </div>
                    </nav>   
            </div>           
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gard/Documents/GitHub/laravelparking/resources/views/users/index.blade.php ENDPATH**/ ?>