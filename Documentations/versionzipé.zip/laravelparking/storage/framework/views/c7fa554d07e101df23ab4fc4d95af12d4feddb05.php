<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        <h4>Vous pouvez changer la durée des réservations ici :</h4>
    </h2>
</div>
<div class="container">
    <div class="container p-6 bg-white border-b border-gray-200">

        <?php echo Form::open(['route' => 'users.updateduree']); ?>

            La durée est fixé à <?php echo e(Form::number('modif', $duree, ['class' => "size='10'"])); ?> jours
            <br>
            <?php echo e(Form::submit('Valider', ['class' => 'btn btn-success'])); ?>

        <?php echo Form::close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gard/Documents/GitHub/laravelparking/resources/views/users/setduree.blade.php ENDPATH**/ ?>