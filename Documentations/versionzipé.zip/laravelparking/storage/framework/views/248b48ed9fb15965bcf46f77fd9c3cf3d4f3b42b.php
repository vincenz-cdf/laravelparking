<div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(route('dashboard.index')); ?>">&#x2800 Accueil &#x2800<span class="sr-only"></span></a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(route('users.show', Auth::User()->id)); ?>">&#x2800 Historique &#x2800<span class="sr-only"></span></a>
      </li>
    </ul>
</div><?php /**PATH /home/gard/Documents/GitHub/laravelparking/resources/views/layouts/navigationSalarie.blade.php ENDPATH**/ ?>