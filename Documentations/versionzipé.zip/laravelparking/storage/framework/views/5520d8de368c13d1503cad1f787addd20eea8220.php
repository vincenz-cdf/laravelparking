<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        <h4>Bonjour ! <?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->prenom); ?></h4>
    </h2>
</div>
<div class="container">
    <div class="container p-6 bg-white border-b border-gray-200">

        <?php $__empty_1 = true; $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php if($reservation->finished_at > $currentDateTime): ?>
                Vous avez actuellement une place au :
                <?php echo e($reservation->place->libelle); ?>

                <br>
                <a href="<?php echo e(route('users.dereserve', $reservation->id)); ?>">
                    <button class="btn btn-warning"> Renoncer à la place </button>
                </a>
            <?php else: ?>
                <?php if($reservation->finished_at < $currentDateTime): ?>
                    <span>Vous n'avez actuellement pas de place attribué</span>
                    <br>
                    <span>Cliquez sur le bouton en dessous vous en avoir une</span>
                    <br>
                    <a href="<?php echo e(route('users.reserve')); ?>">
                        <button class="btn btn-success"> Réserver une place </button>
                    </a>
                <?php endif; ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <span>Vous n'avez actuellement pas de place attribué</span>
            <br>
            <span>Cliquez sur le bouton en dessous vous en avoir une</span>
            <br>
            <a href="<?php echo e(route('users.reserve')); ?>">
                <button class="btn btn-success"> Réserver une place </button>
            </a>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gard/Documents/GitHub/laravelparking/resources/views/salarie/dashboard.blade.php ENDPATH**/ ?>